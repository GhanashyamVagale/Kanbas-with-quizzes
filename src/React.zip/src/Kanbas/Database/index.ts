import users from "./users.json";
import enrollments from "./enrollments.json";
export { users, enrollments };
